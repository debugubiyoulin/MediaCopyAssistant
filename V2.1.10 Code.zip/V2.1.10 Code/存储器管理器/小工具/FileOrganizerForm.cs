﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MediaCopyAssistant
{
    public partial class FileOrganizerForm : Form
    {
        // 文件类型定义
        private static readonly string[] PhotoExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp" };
        private static readonly string[] VideoExtensions = { ".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".webm" };
        private static readonly string[] DocumentExtensions = { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf" };
        private static readonly string[] ArchiveExtensions = { ".zip", ".rar", ".7z", ".tar", ".gz" };

        // RAW 文件格式定义
        private static readonly string[] RawPhotoExtensions = {
            ".cr2", ".cr3", ".crw",      // 佳能
            ".nef", ".nrw",              // 尼康
            ".arw", ".sr2", ".srf",      // 索尼
            ".raf", ".fff",              // 富士
            ".rw2", ".raw",              // 松下
            ".orf",                      // 奥林巴斯
            ".pef", ".dng",              // 宾得
            ".x3f",                      // 适马
            ".dng", ".rwl",              // 徕卡
            ".3fr",                      // 哈苏
            ".iiq"                       // 飞思
        };

        private string selectedFolderPath = "";
        private string targetFolderPath = "";
        private bool organizeByYear = false;
        private bool organizeByYearMonth = false;
        private bool flattenSubdirectories = false;
        private bool createRawFolder = false;
        private BackgroundWorker backgroundWorker;
        private ToolTip toolTip;

        // 添加控件引用
        private ProgressBar progressBar;
        private Label progressLabel;
        private ListBox fileListBox;
        private Button organizeButton;
        private Button resetButton;
        private Button cancelButton;
        private Label statusLabel;
        private TextBox previewTextBox;
        private TextBox explanationTextBox;

        // 添加速度显示相关控件
        private Label speedLabel;
        private Label progressInfoLabel;
        private Label timeInfoLabel;

        private DateTime operationStartTime; // 操作开始时间
        private long totalBytesToCopy = 0; // 记录总字节数
        private long bytesCopiedSoFar = 0; // 记录已拷贝字节数
        private DateTime lastSpeedUpdateTime = DateTime.MinValue; // 上次速度更新时间
        private long lastBytesCopied = 0; // 上次更新速度时的字节数

        public FileOrganizerForm()
        {
            InitializeComponent();
            SetupUI();
            SetupBackgroundWorker();
        }

        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 2, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.Text = "文件分类整理工具";
            this.Size = new Size(900, 1050); // 增加高度以容纳新内容
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            this.Icon = MediaCopyAssistant.Properties.Resources.文件批量重命名工具图标;
            this.ResumeLayout(false);
        }

        private void SetupUI()
        {
            // 初始化工具提示
            toolTip = new ToolTip();
            toolTip.AutoPopDelay = 5000;
            toolTip.InitialDelay = 1000;
            toolTip.ReshowDelay = 500;
            toolTip.ShowAlways = true;

            // 标题
            Label titleLabel = new Label()
            {
                Text = "📁 文件分类整理工具",
                Font = GetDefaultFont(18, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Location = new Point(20, 20),
                Size = new Size(400, 40),
                TextAlign = ContentAlignment.MiddleLeft
            };
            this.Controls.Add(titleLabel);

            // 功能说明和预览区域 - 使用TabControl实现滑动效果
            TabControl previewTabControl = new TabControl()
            {
                Location = new Point(20, 70),
                Size = new Size(850, 180), // 增大高度
                Font = GetDefaultFont(9)
            };

            // 功能说明标签页
            TabPage explanationTab = new TabPage()
            {
                Text = "📋 功能说明",
                BackColor = Color.White
            };

            // 功能说明文本 - 使用带滚动条的文本框
            explanationTextBox = new TextBox()
            {
                Text = "📁 文件分类整理工具" + Environment.NewLine + Environment.NewLine +
                       "• 自动按文件类型分类：照片、视频、文档、压缩包等" + Environment.NewLine +
                       "• 支持按时间分类：按年份或年月组织文件" + Environment.NewLine +
                       "• 处理子文件夹：可选择是否保持原有目录结构" + Environment.NewLine +
                       "• 专门支持相机RAW格式文件" + Environment.NewLine +
                       "• 安全操作：先复制后整理，确保数据安全" + Environment.NewLine + Environment.NewLine +
                       "支持的文件格式：" + Environment.NewLine +
                       "📷 照片: JPG, PNG, GIF, BMP, TIFF, WEBP" + Environment.NewLine +
                       "🎥 视频: MP4, MOV, AVI, MKV, WMV, FLV, WEBM" + Environment.NewLine +
                       "📄 文档: PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, TXT" + Environment.NewLine +
                       "📦 压缩包: ZIP, RAR, 7Z, TAR, GZ" + Environment.NewLine +
                       "🎞️ RAW照片: CR2, NEF, ARW, RAF, DNG 等专业格式" + Environment.NewLine + Environment.NewLine +
                       "使用步骤：" + Environment.NewLine +
                       "1. 选择源文件夹（要整理的文件所在位置）" + Environment.NewLine +
                       "2. 选择目标文件夹（整理后文件保存位置）" + Environment.NewLine +
                       "3. 设置整理选项（时间分类、子文件夹处理等）" + Environment.NewLine +
                       "4. 点击开始整理按钮" + Environment.NewLine + Environment.NewLine +
                       "注意事项：" + Environment.NewLine +
                       "• 确保目标驱动器有足够空间（建议源文件大小的1.5倍）" + Environment.NewLine +
                       "• 整理过程中请不要关闭程序" + Environment.NewLine +
                       "• 重要文件建议先备份",
                Location = new Point(10, 10),
                Size = new Size(810, 130), // 增大文本框高度
                Font = GetDefaultFont(9),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.FromArgb(250, 250, 250)
            };
            explanationTab.Controls.Add(explanationTextBox);

            // 预览标签页
            TabPage previewTab = new TabPage()
            {
                Text = "👀 整理预览",
                BackColor = Color.White
            };

            // 预览文本框 - 使用带滚动条的文本框
            previewTextBox = new TextBox()
            {
                Location = new Point(10, 10),
                Size = new Size(810, 130), // 增大文本框高度
                Font = new Font("Consolas", 9), // 使用等宽字体显示目录结构
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.FromArgb(250, 250, 250)
            };
            previewTab.Controls.Add(previewTextBox);

            previewTabControl.Controls.Add(explanationTab);
            previewTabControl.Controls.Add(previewTab);
            this.Controls.Add(previewTabControl);

            // 调整后续控件的位置
            int baseY = 270; // 因为TabControl高度增加了，所以基础Y坐标要调整

            // 选择源文件夹区域
            GroupBox sourceFolderGroup = new GroupBox()
            {
                Text = "选择源文件夹",
                Font = GetDefaultFont(10, FontStyle.Bold),
                Location = new Point(20, baseY),
                Size = new Size(850, 80),
                ForeColor = Color.DarkBlue
            };

            // 源文件夹路径文本框
            TextBox sourceFolderPathText = new TextBox()
            {
                Location = new Point(20, 30),
                Size = new Size(600, 25),
                Font = GetDefaultFont(9),
                ReadOnly = true
            };

            // 浏览源文件夹按钮
            Button browseSourceButton = new Button()
            {
                Text = "浏览文件夹",
                Location = new Point(630, 30),
                Size = new Size(100, 25),
                Font = GetDefaultFont(9),
                BackColor = Color.LightBlue
            };
            browseSourceButton.Click += (s, e) => BrowseFolder(sourceFolderPathText, "选择要整理的源文件夹");

            sourceFolderGroup.Controls.Add(sourceFolderPathText);
            sourceFolderGroup.Controls.Add(browseSourceButton);
            this.Controls.Add(sourceFolderGroup);

            // 选择目标文件夹区域
            GroupBox targetFolderGroup = new GroupBox()
            {
                Text = "选择整理目标位置",
                Font = GetDefaultFont(10, FontStyle.Bold),
                Location = new Point(20, baseY + 100),
                Size = new Size(850, 80),
                ForeColor = Color.DarkBlue
            };

            // 目标文件夹路径文本框
            TextBox targetFolderPathText = new TextBox()
            {
                Location = new Point(20, 30),
                Size = new Size(600, 25),
                Font = GetDefaultFont(9),
                ReadOnly = true
            };

            // 浏览目标文件夹按钮
            Button browseTargetButton = new Button()
            {
                Text = "浏览文件夹",
                Location = new Point(630, 30),
                Size = new Size(100, 25),
                Font = GetDefaultFont(9),
                BackColor = Color.LightBlue
            };
            browseTargetButton.Click += (s, e) => BrowseFolder(targetFolderPathText, "选择整理后的文件保存位置");

            targetFolderGroup.Controls.Add(targetFolderPathText);
            targetFolderGroup.Controls.Add(browseTargetButton);
            this.Controls.Add(targetFolderGroup);

            // 设置区域
            GroupBox settingsGroup = new GroupBox()
            {
                Text = "整理设置",
                Font = GetDefaultFont(10, FontStyle.Bold),
                Location = new Point(20, baseY + 200),
                Size = new Size(850, 130),
                ForeColor = Color.DarkBlue
            };

            int settingsY = 25;
            int settingsX1 = 20;
            int settingsX2 = 250;
            int settingsX3 = 480;

            // 按年分类复选框
            CheckBox yearCheck = new CheckBox()
            {
                Text = "按时间分类（年）",
                Location = new Point(settingsX1, settingsY),
                Size = new Size(150, 25),
                Font = GetDefaultFont(9),
                Checked = false
            };
            yearCheck.CheckedChanged += (s, e) =>
            {
                organizeByYear = yearCheck.Checked;
                if (yearCheck.Checked)
                {
                    organizeByYearMonth = false;
                    UpdateYearMonthCheckBoxes();
                }
                UpdatePreview();
            };
            toolTip.SetToolTip(yearCheck, "按照文件的最后修改时间，在分类文件夹中创建年子文件夹");

            // 按年月分类复选框
            CheckBox yearMonthCheck = new CheckBox()
            {
                Text = "按时间分类（年/月）",
                Location = new Point(settingsX1, settingsY + 30),
                Size = new Size(180, 25),
                Font = GetDefaultFont(9),
                Checked = false
            };
            yearMonthCheck.CheckedChanged += (s, e) =>
            {
                organizeByYearMonth = yearMonthCheck.Checked;
                if (yearMonthCheck.Checked)
                {
                    organizeByYear = false;
                    UpdateYearMonthCheckBoxes();
                }
                UpdatePreview();
            };
            toolTip.SetToolTip(yearMonthCheck, "按照文件的最后修改时间，在分类文件夹中创建年/月子文件夹");

            // 忽略子文件夹复选框
            CheckBox flattenCheck = new CheckBox()
            {
                Text = "忽略子文件夹",
                Location = new Point(settingsX2, settingsY),
                Size = new Size(200, 25),
                Font = GetDefaultFont(9),
                Checked = false
            };
            flattenCheck.CheckedChanged += (s, e) => {
                flattenSubdirectories = flattenCheck.Checked;
                UpdatePreview();
            };
            toolTip.SetToolTip(flattenCheck, "选择此项会先将所有子文件夹中的文件移动到根目录，然后进行整理");

            // 创建RAW文件夹复选框
            CheckBox rawFolderCheck = new CheckBox()
            {
                Text = "添加相机原始文件文件夹",
                Location = new Point(settingsX2, settingsY + 30),
                Size = new Size(220, 25),
                Font = GetDefaultFont(9),
                Checked = false
            };
            rawFolderCheck.CheckedChanged += (s, e) => {
                createRawFolder = rawFolderCheck.Checked;
                UpdatePreview();
            };
            toolTip.SetToolTip(rawFolderCheck, "为相机RAW格式文件创建单独的文件夹，支持CR2、NEF、ARW等格式");

            // 设置说明标签
            Label settingsExplanation = new Label()
            {
                Text = "说明：\n" +
                       "• 时间分类选项只能选择一个\n" +
                       "• RAW文件夹专门存放相机原始格式文件\n" +
                       "• 忽略子文件夹会扁平化处理所有文件",
                Location = new Point(settingsX3, settingsY),
                Size = new Size(300, 80),
                Font = GetDefaultFont(8),
                ForeColor = Color.Gray
            };

            settingsGroup.Controls.Add(yearCheck);
            settingsGroup.Controls.Add(yearMonthCheck);
            settingsGroup.Controls.Add(flattenCheck);
            settingsGroup.Controls.Add(rawFolderCheck);
            settingsGroup.Controls.Add(settingsExplanation);
            this.Controls.Add(settingsGroup);

            // 文件预览区域
            GroupBox previewGroup = new GroupBox()
            {
                Text = "文件预览",
                Font = GetDefaultFont(10, FontStyle.Bold),
                Location = new Point(20, baseY + 350),
                Size = new Size(850, 150),
                ForeColor = Color.DarkBlue
            };

            // 文件列表
            fileListBox = new ListBox()
            {
                Location = new Point(20, 30),
                Size = new Size(810, 110),
                Font = GetDefaultFont(9),
                ScrollAlwaysVisible = true
            };

            previewGroup.Controls.Add(fileListBox);
            this.Controls.Add(previewGroup);

            // 进度条区域
            GroupBox progressGroup = new GroupBox()
            {
                Text = "整理进度",
                Font = GetDefaultFont(10, FontStyle.Bold),
                Location = new Point(20, baseY + 520),
                Size = new Size(850, 80),
                ForeColor = Color.DarkBlue
            };

            // 进度条
            progressBar = new ProgressBar()
            {
                Location = new Point(20, 30),
                Size = new Size(810, 25),
                Minimum = 0,
                Maximum = 100,
                Value = 0
            };

            // 进度标签
            progressLabel = new Label()
            {
                Text = "等待开始...",
                Location = new Point(20, 60),
                Size = new Size(810, 20),
                Font = GetDefaultFont(9),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.DarkBlue
            };

            progressGroup.Controls.Add(progressBar);
            progressGroup.Controls.Add(progressLabel);
            this.Controls.Add(progressGroup);

            // 按钮区域和速度显示区域
            Panel buttonPanel = new Panel()
            {
                Location = new Point(20, baseY + 620),
                Size = new Size(850, 80) // 增加高度以容纳速度显示
            };

            // 开始整理按钮
            organizeButton = new Button()
            {
                Text = "🚀 开始整理",
                Location = new Point(20, 20),
                Size = new Size(120, 40),
                Font = GetDefaultFont(10, FontStyle.Bold),
                BackColor = Color.LightGreen
            };
            organizeButton.Click += (s, e) => StartOrganizeFiles(sourceFolderPathText.Text, targetFolderPathText.Text);
            toolTip.SetToolTip(organizeButton, "开始整理文件");

            // 重置按钮
            resetButton = new Button()
            {
                Text = "🔄 重置",
                Location = new Point(160, 20),
                Size = new Size(80, 40),
                Font = GetDefaultFont(10),
                BackColor = Color.LightGray
            };
            resetButton.Click += (s, e) => ResetUI(sourceFolderPathText, targetFolderPathText);
            toolTip.SetToolTip(resetButton, "重置所有设置");

            // 取消按钮
            cancelButton = new Button()
            {
                Text = "❌ 取消",
                Location = new Point(260, 20),
                Size = new Size(80, 40),
                Font = GetDefaultFont(10),
                BackColor = Color.LightCoral,
                Enabled = false
            };
            cancelButton.Click += (s, e) => CancelOrganize();
            toolTip.SetToolTip(cancelButton, "取消当前操作");

            // 在取消按钮右边添加实时速度显示区域
            int infoStartX = 360;
            int infoWidth = 480;

            // 创建分组框用于显示速度信息
            GroupBox speedGroup = new GroupBox()
            {
                Text = "实时信息",
                Font = GetDefaultFont(9, FontStyle.Bold),
                Location = new Point(infoStartX, 0),
                Size = new Size(infoWidth, 90),
                ForeColor = Color.DarkBlue
            };

            // 速度显示标签
            speedLabel = new Label()
            {
                Text = "速度: --",
                Location = new Point(10, 20),
                Size = new Size(infoWidth - 20, 20),
                Font = GetDefaultFont(9),
                ForeColor = Color.DarkGreen
            };

            // 进度信息标签
            progressInfoLabel = new Label()
            {
                Text = "进度: 0% | 已处理: 0/0 文件",
                Location = new Point(10, 40),
                Size = new Size(infoWidth - 20, 20),
                Font = GetDefaultFont(9),
                ForeColor = Color.DarkBlue
            };

            // 时间信息标签
            timeInfoLabel = new Label()
            {
                Text = "已用时: -- | 剩余: --",
                Location = new Point(10, 60),
                Size = new Size(infoWidth - 20, 20),
                Font = GetDefaultFont(9),
                ForeColor = Color.DarkSlateBlue
            };

            speedGroup.Controls.Add(speedLabel);
            speedGroup.Controls.Add(progressInfoLabel);
            speedGroup.Controls.Add(timeInfoLabel);

            buttonPanel.Controls.Add(organizeButton);
            buttonPanel.Controls.Add(resetButton);
            buttonPanel.Controls.Add(cancelButton);
            buttonPanel.Controls.Add(speedGroup);
            this.Controls.Add(buttonPanel);

            // 状态标签
            statusLabel = new Label()
            {
                Text = "准备就绪",
                Location = new Point(20, baseY + 715), // 调整位置
                Size = new Size(400, 20),
                Font = GetDefaultFont(9),
                ForeColor = Color.DarkBlue
            };
            this.Controls.Add(statusLabel);

            // 更新文件列表
            sourceFolderPathText.TextChanged += (s, e) =>
            {
                selectedFolderPath = sourceFolderPathText.Text;
                UpdateFileList();
            };

            targetFolderPathText.TextChanged += (s, e) =>
            {
                targetFolderPath = targetFolderPathText.Text;
            };

            // 存储复选框引用以便后续更新
            this.Tag = new { YearCheck = yearCheck, YearMonthCheck = yearMonthCheck };

            // 初始更新预览
            UpdatePreview();
        }

        private void UpdateYearMonthCheckBoxes()
        {
            // 获取存储的复选框引用
            var checks = this.Tag as dynamic;
            if (checks != null)
            {
                checks.YearCheck.Checked = organizeByYear;
                checks.YearMonthCheck.Checked = organizeByYearMonth;
            }
        }

        private void UpdatePreview()
        {
            if (previewTextBox == null) return;

            string baseStructure = "整理后目录结构预览：" + Environment.NewLine;
            string targetFolder = "目标文件夹/" + Environment.NewLine;

            List<string> categories = new List<string> {
                "├── 📷 照片/" + Environment.NewLine,
                "├── 🎥 视频/" + Environment.NewLine,
                "├── 📄 文档/" + Environment.NewLine,
                "├── 📦 压缩包/" + Environment.NewLine
            };

            if (createRawFolder)
            {
                categories.Insert(1, "├── 🎞️ RAW照片/" + Environment.NewLine); // 在照片后面插入RAW文件夹
            }

            categories.Add("└── 📁 其他/" + Environment.NewLine);

            // 构建时间分类结构
            if (organizeByYear)
            {
                for (int i = 0; i < categories.Count; i++)
                {
                    string category = categories[i].Substring(4); // 移除前缀
                    categories[i] = $"├── {category}" + Environment.NewLine +
                                   $"│   └── 2024/" + Environment.NewLine;
                }
            }
            else if (organizeByYearMonth)
            {
                for (int i = 0; i < categories.Count; i++)
                {
                    string category = categories[i].Substring(4); // 移除前缀
                    categories[i] = $"├── {category}" + Environment.NewLine +
                                   $"│   └── 2024/" + Environment.NewLine +
                                   $"│       └── 01/" + Environment.NewLine;
                }
            }

            string finalStructure = baseStructure + targetFolder + string.Join("\n", categories);

            // 添加设置说明
            finalStructure += "\n\n当前设置：";
            if (organizeByYear)
                finalStructure += "\n• 按年份分类";
            else if (organizeByYearMonth)
                finalStructure += "\n• 按年月分类";
            else
                finalStructure += "\n• 不按时间分类";

            if (flattenSubdirectories)
                finalStructure += "\n• 忽略子文件夹结构";
            else
                finalStructure += "\n• 保持子文件夹结构";

            if (createRawFolder)
                finalStructure += "\n• 创建RAW照片文件夹";
            else
                finalStructure += "\n• 不创建RAW照片文件夹";

            previewTextBox.Text = finalStructure;
        }

        private void SetupBackgroundWorker()
        {
            backgroundWorker = new BackgroundWorker();
            backgroundWorker.WorkerReportsProgress = true;
            backgroundWorker.WorkerSupportsCancellation = true;
            backgroundWorker.DoWork += BackgroundWorker_DoWork;
            backgroundWorker.ProgressChanged += BackgroundWorker_ProgressChanged;
            backgroundWorker.RunWorkerCompleted += BackgroundWorker_RunWorkerCompleted;
        }

        private void BackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            OrganizeArguments args = (OrganizeArguments)e.Argument;
            BackgroundWorker worker = (BackgroundWorker)sender;

            try
            {
                // 第一步：复制所有文件到临时目录（位于目标文件夹内）
                string tempFolder = Path.Combine(args.TargetFolder, "临时整理目录_" + Guid.NewGuid().ToString());
                Directory.CreateDirectory(tempFolder);

                var allFiles = Directory.GetFiles(args.SourceFolder, "*.*", SearchOption.AllDirectories);
                int totalFiles = allFiles.Count();
                int processedFiles = 0;
                long totalBytesCopied = 0;
                DateTime copyEndTime = DateTime.MinValue;

                // 复制阶段
                foreach (string sourceFile in allFiles)
                {
                    if (worker.CancellationPending)
                    {
                        Directory.Delete(tempFolder, true);
                        e.Cancel = true;
                        return;
                    }

                    try
                    {
                        string relativePath = GetRelativePath(sourceFile, args.SourceFolder);
                        string tempFilePath = Path.Combine(tempFolder, relativePath);

                        // 创建目标目录
                        string tempFileDir = Path.GetDirectoryName(tempFilePath);
                        if (!Directory.Exists(tempFileDir))
                        {
                            Directory.CreateDirectory(tempFileDir);
                        }

                        // 获取文件大小
                        long fileSize = 0;
                        try
                        {
                            FileInfo fi = new FileInfo(sourceFile);
                            fileSize = fi.Length;
                        }
                        catch
                        {
                            // 如果无法获取文件大小，使用默认值
                            fileSize = 1024; // 1KB 默认值
                        }

                        // 复制文件到临时目录
                        File.Copy(sourceFile, tempFilePath, true);

                        processedFiles++;
                        totalBytesCopied += fileSize;
                        args.BytesCopied = totalBytesCopied;

                        // 计算实时速度
                        DateTime now = DateTime.Now;
                        TimeSpan elapsed = now - lastSpeedUpdateTime;

                        // 每处理5个文件或至少1秒更新一次速度
                        if (processedFiles % 5 == 0 || elapsed.TotalSeconds >= 1.0)
                        {
                            long bytesSinceLastUpdate = totalBytesCopied - lastBytesCopied;
                            double currentSpeed = bytesSinceLastUpdate / Math.Max(elapsed.TotalSeconds, 0.1);

                            // 报告进度 - 复制阶段占50%进度
                            int progressPercentage = (int)((double)processedFiles / totalFiles * 50);
                            worker.ReportProgress(progressPercentage, new ProgressInfo
                            {
                                FileName = Path.GetFileName(sourceFile),
                                Stage = "复制",
                                ProcessedFiles = processedFiles,
                                TotalFiles = totalFiles,
                                BytesCopied = totalBytesCopied,
                                TotalBytes = args.TotalBytesToCopy,
                                CurrentSpeed = currentSpeed,
                                IsError = false
                            });

                            lastBytesCopied = totalBytesCopied;
                            lastSpeedUpdateTime = now;
                        }
                    }
                    catch (Exception ex)
                    {
                        worker.ReportProgress(-1, new ProgressInfo
                        {
                            FileName = Path.GetFileName(sourceFile),
                            ErrorMessage = $"复制失败: {ex.Message}",
                            IsError = true
                        });
                    }
                }

                // 复制完成，报告100%进度用于复制阶段
                worker.ReportProgress(50, new ProgressInfo
                {
                    Stage = "复制完成",
                    ProcessedFiles = totalFiles,
                    TotalFiles = totalFiles,
                    BytesCopied = totalBytesCopied,
                    TotalBytes = args.TotalBytesToCopy,
                    IsError = false
                });

                // 记录拷贝结束时间
                copyEndTime = DateTime.Now;

                // 第二步：在临时目录中进行整理
                OrganizeFilesInFolder(tempFolder, args.TargetFolder, worker, totalFiles, totalBytesCopied);

                // 清理临时目录
                Directory.Delete(tempFolder, true);

                e.Result = new OrganizeResult
                {
                    Success = true,
                    ProcessedFiles = processedFiles,
                    TotalFiles = totalFiles,
                    TargetFolder = args.TargetFolder,
                    TotalBytes = args.TotalBytesToCopy,
                    BytesCopied = totalBytesCopied,
                    CopyEndTime = copyEndTime
                };
            }
            catch (Exception ex)
            {
                e.Result = new OrganizeResult
                {
                    Success = false,
                    ErrorMessage = ex.Message
                };
            }
        }

        /// <summary>
        /// 在指定文件夹内进行文件整理
        /// </summary>
        private void OrganizeFilesInFolder(string sourceFolder, string targetFolder, BackgroundWorker worker, int totalFiles, long bytesCopied)
        {
            try
            {
                // 如果选择了忽略子文件夹，先将所有文件移动到根目录
                if (flattenSubdirectories)
                {
                    FlattenSubdirectories(sourceFolder, worker, totalFiles);
                }

                // 获取所有文件
                var files = Directory.GetFiles(sourceFolder, "*.*", SearchOption.AllDirectories);
                int processedFiles = 0;
                int totalFilesInStage = files.Length;

                // 创建分类文件夹
                List<string> categories = new List<string> { "照片", "视频", "文档", "压缩包" };

                if (createRawFolder)
                {
                    categories.Insert(1, "RAW照片"); // 在照片后面插入RAW文件夹
                }

                categories.Add("其他");

                foreach (string category in categories)
                {
                    string categoryPath = Path.Combine(targetFolder, category);
                    Directory.CreateDirectory(categoryPath);
                }

                // 整理文件
                foreach (string sourceFile in files)
                {
                    if (worker.CancellationPending)
                    {
                        return;
                    }

                    try
                    {
                        string fileName = Path.GetFileName(sourceFile);
                        string extension = Path.GetExtension(sourceFile).ToLowerInvariant();
                        string relativePath = GetRelativePath(sourceFile, sourceFolder);

                        // 确定文件类别
                        string category = "其他";
                        if (createRawFolder && RawPhotoExtensions.Contains(extension))
                        {
                            category = "RAW照片";
                        }
                        else if (PhotoExtensions.Contains(extension))
                        {
                            category = "照片";
                        }
                        else if (VideoExtensions.Contains(extension))
                        {
                            category = "视频";
                        }
                        else if (DocumentExtensions.Contains(extension))
                        {
                            category = "文档";
                        }
                        else if (ArchiveExtensions.Contains(extension))
                        {
                            category = "压缩包";
                        }

                        // 构建目标路径
                        string targetPath = Path.Combine(targetFolder, category);

                        if (organizeByYear || organizeByYearMonth)
                        {
                            DateTime fileTime = File.GetLastWriteTime(sourceFile);
                            string yearFolder = fileTime.ToString("yyyy");

                            targetPath = Path.Combine(targetPath, yearFolder);

                            if (organizeByYearMonth)
                            {
                                string monthFolder = fileTime.ToString("MM");
                                targetPath = Path.Combine(targetPath, monthFolder);
                            }
                        }

                        // 如果启用了忽略子文件夹，则不保持目录结构
                        if (!flattenSubdirectories && !string.IsNullOrEmpty(relativePath))
                        {
                            string relativeDir = Path.GetDirectoryName(relativePath);
                            if (!string.IsNullOrEmpty(relativeDir))
                            {
                                targetPath = Path.Combine(targetPath, relativeDir);
                            }
                        }

                        Directory.CreateDirectory(targetPath);

                        // 处理重名文件
                        string destFile = Path.Combine(targetPath, fileName);
                        if (File.Exists(destFile))
                        {
                            string nameWithoutExt = Path.GetFileNameWithoutExtension(fileName);
                            string ext = Path.GetExtension(fileName);
                            int counter = 1;

                            do
                            {
                                destFile = Path.Combine(targetPath, $"{nameWithoutExt}_{counter}{ext}");
                                counter++;
                            } while (File.Exists(destFile) && counter < 1000);
                        }

                        // 移动文件到最终位置
                        File.Move(sourceFile, destFile);

                        processedFiles++;

                        // 报告进度 - 整理阶段占50%进度（从50%到100%）
                        int progressPercentage = 50 + (int)((double)processedFiles / files.Length * 50);

                        // 每处理5个文件或完成时报告进度
                        if (processedFiles % 5 == 0 || processedFiles == files.Length)
                        {
                            worker.ReportProgress(progressPercentage, new ProgressInfo
                            {
                                FileName = fileName,
                                Stage = "整理",
                                ProcessedFiles = processedFiles,
                                TotalFilesInStage = totalFilesInStage,
                                TotalFiles = totalFiles,
                                IsError = false
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        worker.ReportProgress(-1, new ProgressInfo
                        {
                            FileName = Path.GetFileName(sourceFile),
                            ErrorMessage = $"整理失败: {ex.Message}",
                            IsError = true
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"整理文件时出错: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 将子文件夹中的所有文件移动到根目录
        /// </summary>
        private void FlattenSubdirectories(string sourceFolder, BackgroundWorker worker, int totalFiles)
        {
            try
            {
                // 获取所有子目录
                var subdirectories = Directory.GetDirectories(sourceFolder, "*", SearchOption.AllDirectories);

                // 按路径深度倒序排序，确保先处理最深层的文件夹
                var sortedDirectories = subdirectories.OrderByDescending(d => d.Count(c => c == Path.DirectorySeparatorChar)).ToArray();

                int movedFiles = 0;
                int totalFilesToMove = sortedDirectories.SelectMany(d => Directory.GetFiles(d)).Count();

                foreach (string subdirectory in sortedDirectories)
                {
                    if (worker.CancellationPending) return;

                    try
                    {
                        // 获取子目录中的所有文件
                        var files = Directory.GetFiles(subdirectory);

                        foreach (string file in files)
                        {
                            if (worker.CancellationPending) return;

                            string fileName = Path.GetFileName(file);
                            string destFile = Path.Combine(sourceFolder, fileName);

                            // 处理重名文件
                            if (File.Exists(destFile))
                            {
                                string nameWithoutExt = Path.GetFileNameWithoutExtension(fileName);
                                string ext = Path.GetExtension(fileName);
                                int counter = 1;

                                do
                                {
                                    destFile = Path.Combine(sourceFolder, $"{nameWithoutExt}_{counter}{ext}");
                                    counter++;
                                } while (File.Exists(destFile) && counter < 1000);
                            }

                            // 移动文件到根目录
                            File.Move(file, destFile);

                            movedFiles++;

                            // 每移动5个文件报告一次进度
                            if (movedFiles % 5 == 0)
                            {
                                int progressPercentage = 50 + (int)((double)movedFiles / totalFilesToMove * 25);
                                worker.ReportProgress(progressPercentage, new ProgressInfo
                                {
                                    FileName = $"移动: {fileName}",
                                    Stage = "移动文件",
                                    ProcessedFiles = movedFiles,
                                    TotalFilesInStage = totalFilesToMove,
                                    TotalFiles = totalFiles,
                                    IsError = false
                                });
                            }
                        }

                        // 删除空文件夹
                        if (!Directory.GetFiles(subdirectory).Any() && !Directory.GetDirectories(subdirectory).Any())
                        {
                            Directory.Delete(subdirectory, false);
                        }
                    }
                    catch (Exception ex)
                    {
                        // 记录错误但继续处理其他文件夹
                        worker.ReportProgress(-1, new ProgressInfo
                        {
                            FileName = Path.GetFileName(subdirectory),
                            ErrorMessage = ex.Message,
                            IsError = true
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"处理子文件夹时出错: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 计算文件夹总大小
        /// </summary>
        private long CalculateFolderSize(string folderPath)
        {
            long size = 0;
            try
            {
                var files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories);
                foreach (string file in files)
                {
                    try
                    {
                        FileInfo fi = new FileInfo(file);
                        size += fi.Length;
                    }
                    catch
                    {
                        // 忽略无法访问的文件
                    }
                }
            }
            catch
            {
                // 忽略无法访问的文件夹
            }
            return size;
        }

        /// <summary>
        /// 获取驱动器可用空间
        /// </summary>
        private long GetDriveFreeSpace(string folderPath)
        {
            try
            {
                string driveRoot = Path.GetPathRoot(folderPath);
                DriveInfo drive = new DriveInfo(driveRoot);
                return drive.AvailableFreeSpace;
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// 格式化文件大小
        /// </summary>
        private string FormatFileSize(long bytes)
        {
            string[] suffixes = { "B", "KB", "MB", "GB", "TB" };
            int counter = 0;
            decimal number = bytes;
            while (Math.Round(number / 1024) >= 1)
            {
                number /= 1024;
                counter++;
            }
            return $"{number:n1} {suffixes[counter]}";
        }

        private void BackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // 获取进度信息
            ProgressInfo info = (ProgressInfo)e.UserState;

            // 更新已拷贝字节数
            if (info.BytesCopied > 0)
            {
                this.bytesCopiedSoFar = info.BytesCopied;
            }

            // 更新进度条
            if (e.ProgressPercentage >= 0)
            {
                progressBar.Value = e.ProgressPercentage;
            }

            // 更新基本进度标签
            if (e.ProgressPercentage >= 0)
            {
                progressLabel.Text = $"{info.Stage}中: {e.ProgressPercentage}%";
            }

            // 更新文件列表
            if (info.IsError)
            {
                fileListBox.Items.Add($"✗ 错误: {info.FileName} - {info.ErrorMessage}");
            }
            else if (!string.IsNullOrEmpty(info.FileName))
            {
                fileListBox.Items.Add($"✓ {info.Stage}: {info.FileName}");
            }

            // 自动滚动到列表底部
            if (fileListBox.Items.Count > 0)
            {
                int visibleItems = fileListBox.ClientSize.Height / fileListBox.ItemHeight;
                fileListBox.TopIndex = Math.Max(0, fileListBox.Items.Count - visibleItems + 1);
            }

            // 更新实时信息显示区域
            UpdateRealTimeInfo(info, e.ProgressPercentage);

            // 强制刷新UI
            Application.DoEvents();
        }

        /// <summary>
        /// 更新实时信息显示
        /// </summary>
        private void UpdateRealTimeInfo(ProgressInfo info, int progressPercentage)
        {
            // 更新速度显示
            if (info.CurrentSpeed > 0 && info.Stage == "复制")
            {
                speedLabel.Text = $"速度: {FormatSpeed(info.CurrentSpeed)}";
                speedLabel.ForeColor = Color.DarkGreen;
            }
            else if (progressPercentage > 50)
            {
                speedLabel.Text = "阶段: 整理文件";
                speedLabel.ForeColor = Color.DarkOrange;
            }
            else if (info.Stage == "复制完成")
            {
                speedLabel.Text = "阶段: 复制完成";
                speedLabel.ForeColor = Color.DarkGreen;
            }

            // 更新进度信息
            if (info.TotalFiles > 0)
            {
                if (info.TotalFilesInStage > 0)
                {
                    progressInfoLabel.Text = $"进度: {progressPercentage}% | 已处理: {info.ProcessedFiles}/{info.TotalFilesInStage} 文件";
                }
                else
                {
                    progressInfoLabel.Text = $"进度: {progressPercentage}% | 已处理: {info.ProcessedFiles}/{info.TotalFiles} 文件";
                }

                // 更新已处理数据量
                if (info.BytesCopied > 0 && info.TotalBytes > 0)
                {
                    double copyProgress = (double)info.BytesCopied / info.TotalBytes * 100;
                    progressInfoLabel.Text += $" | 数据: {FormatFileSize(info.BytesCopied)}/{FormatFileSize(info.TotalBytes)} ({copyProgress:F1}%)";
                }
            }

            // 更新时间信息
            if (operationStartTime != DateTime.MinValue)
            {
                TimeSpan elapsed = DateTime.Now - operationStartTime;

                // 只在复制阶段计算剩余时间
                if (info.CurrentSpeed > 0 && info.BytesCopied > 0 && info.TotalBytes > info.BytesCopied)
                {
                    long remainingBytes = info.TotalBytes - info.BytesCopied;
                    TimeSpan remainingTime = TimeSpan.FromSeconds(remainingBytes / info.CurrentSpeed);
                    timeInfoLabel.Text = $"已用时: {FormatTimeSpan(elapsed)} | 剩余: {FormatTimeSpan(remainingTime)}";
                }
                else
                {
                    timeInfoLabel.Text = $"已用时: {FormatTimeSpan(elapsed)} | 剩余: --";
                }
            }
            else
            {
                timeInfoLabel.Text = "已用时: -- | 剩余: --";
            }
        }

        private void BackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // 启用/禁用按钮
            organizeButton.Enabled = true;
            resetButton.Enabled = true;
            cancelButton.Enabled = false;

            // 重置速度显示
            speedLabel.Text = "速度: --";
            progressInfoLabel.Text = "进度: 0% | 已处理: 0/0 文件";
            timeInfoLabel.Text = "已用时: -- | 剩余: --";

            // 使用BeginInvoke确保在UI线程上显示消息框
            this.BeginInvoke(new Action(() =>
            {
                if (e.Cancelled)
                {
                    progressLabel.Text = "操作已取消";
                    MessageBox.Show(this, "整理操作已被取消", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (e.Error != null)
                {
                    progressLabel.Text = "操作出错";
                    MessageBox.Show(this, $"整理过程中出错: {e.Error.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // 重命名变量，避免与外层作用域冲突
                    OrganizeResult organizeResult = (OrganizeResult)e.Result;
                    if (organizeResult.Success)
                    {
                        // 计算总耗时
                        TimeSpan totalTime = DateTime.Now - this.operationStartTime;

                        // 使用真实的拷贝时间计算平均速度
                        TimeSpan copyTime = TimeSpan.Zero;
                        double averageCopySpeed = 0;

                        if (organizeResult.CopyEndTime != DateTime.MinValue)
                        {
                            // 计算真实的拷贝时间
                            copyTime = organizeResult.CopyEndTime - this.operationStartTime;

                            if (copyTime.TotalSeconds > 0 && organizeResult.BytesCopied > 0)
                            {
                                averageCopySpeed = organizeResult.BytesCopied / copyTime.TotalSeconds;
                            }
                        }

                        progressLabel.Text = "整理完成";
                        string message = $"📊 整理完成！\n\n" +
                                       $"📁 文件统计:\n" +
                                       $"共处理: {organizeResult.ProcessedFiles}/{organizeResult.TotalFiles} 个文件\n" +
                                       $"总数据量: {FormatFileSize(organizeResult.BytesCopied)}\n" +
                                       $"📈 性能统计:\n" +
                                       $"拷贝用时: {FormatTimeSpan(copyTime)}\n" +
                                       $"拷贝速度: {FormatSpeed(averageCopySpeed)}\n" +
                                       $"总用时: {FormatTimeSpan(totalTime)}\n" +
                                       $"💾 保存位置:\n{organizeResult.TargetFolder}";

                        if (flattenSubdirectories)
                        {
                            message += "\n\n⚠️ 注意：已将所有子文件夹中的文件移动到根目录进行整理";
                        }

                        if (createRawFolder)
                        {
                            message += "\n✅ 已创建RAW照片文件夹";
                        }

                        MessageBox.Show(this, message, "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // 打开目标文件夹
                        try
                        {
                            System.Diagnostics.Process.Start("explorer.exe", organizeResult.TargetFolder);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(this, $"无法打开文件夹: {ex.Message}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        progressLabel.Text = "整理失败";
                        MessageBox.Show(this, $"整理失败: {organizeResult.ErrorMessage}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }));
        }

        private void BrowseFolder(TextBox folderPathText, string description)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = description;
                dialog.ShowNewFolderButton = true;

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    folderPathText.Text = dialog.SelectedPath;
                }
            }
        }

        private void UpdateFileList()
        {
            fileListBox.Items.Clear();

            if (string.IsNullOrEmpty(selectedFolderPath) || !Directory.Exists(selectedFolderPath))
            {
                statusLabel.Text = "请选择有效的文件夹";
                statusLabel.ForeColor = Color.Red;
                return;
            }

            try
            {
                var files = Directory.GetFiles(selectedFolderPath, "*.*", SearchOption.AllDirectories);
                int fileCount = files.Length;

                fileListBox.BeginUpdate();
                foreach (string file in files.Take(100))
                {
                    string fileName = Path.GetFileName(file);
                    string fileType = GetFileType(file);
                    string relativePath = GetRelativePath(file, selectedFolderPath);
                    string displayText = $"{fileType} {fileName}";

                    // 如果文件不在根目录，显示路径信息
                    if (!string.IsNullOrEmpty(relativePath) && relativePath.Contains(Path.DirectorySeparatorChar))
                    {
                        displayText += $" [{Path.GetDirectoryName(relativePath)}]";
                    }

                    fileListBox.Items.Add(displayText);
                }
                fileListBox.EndUpdate();

                statusLabel.Text = $"找到 {fileCount} 个文件" + (fileCount > 100 ? " (显示前100个)" : "");
                statusLabel.ForeColor = Color.DarkGreen;
            }
            catch (Exception ex)
            {
                statusLabel.Text = $"读取文件时出错: {ex.Message}";
                statusLabel.ForeColor = Color.Red;
            }
        }

        private string GetFileType(string filePath)
        {
            string extension = Path.GetExtension(filePath).ToLowerInvariant();

            if (RawPhotoExtensions.Contains(extension)) return "🎞️";
            if (PhotoExtensions.Contains(extension)) return "📷";
            if (VideoExtensions.Contains(extension)) return "🎥";
            if (DocumentExtensions.Contains(extension)) return "📄";
            if (ArchiveExtensions.Contains(extension)) return "📦";

            return "📁";
        }

        private void StartOrganizeFiles(string sourceFolder, string targetFolder)
        {
            // 验证输入
            if (string.IsNullOrEmpty(sourceFolder) || !Directory.Exists(sourceFolder))
            {
                MessageBox.Show(this, "请选择有效的源文件夹", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(targetFolder) || !Directory.Exists(Path.GetDirectoryName(targetFolder)))
            {
                MessageBox.Show(this, "请选择有效的目标文件夹", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 计算源文件夹大小
            long sourceSize = CalculateFolderSize(sourceFolder);
            long availableSpace = GetDriveFreeSpace(targetFolder);

            // 检查磁盘空间
            if (availableSpace < sourceSize * 1.5)
            {
                string message = $"磁盘空间不足！\n\n" +
                               $"源文件夹大小: {FormatFileSize(sourceSize)}\n" +
                               $"目标驱动器可用空间: {FormatFileSize(availableSpace)}\n" +
                               $"需要至少 {FormatFileSize((long)(sourceSize * 1.5))} (源文件大小的1.5倍)\n\n" +
                               $"请清理目标驱动器空间或选择其他目标位置。";

                MessageBox.Show(this, message, "空间不足", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 构建确认消息
            string confirmMessage = $"空间检查通过！\n\n" +
                                  $"源文件夹大小: {FormatFileSize(sourceSize)}\n" +
                                  $"目标驱动器可用空间: {FormatFileSize(availableSpace)}\n" +
                                  $"需要空间: {FormatFileSize((long)(sourceSize * 1.5))} (源文件大小的1.5倍)\n\n";

            // 添加功能说明
            if (organizeByYear)
            {
                confirmMessage += "• 将按年份分类文件\n";
            }
            else if (organizeByYearMonth)
            {
                confirmMessage += "• 将按年月分类文件\n";
            }

            if (flattenSubdirectories)
            {
                confirmMessage += "• 将忽略子文件夹结构\n";
            }

            if (createRawFolder)
            {
                confirmMessage += "• 将创建RAW照片专用文件夹\n";
            }

            confirmMessage += "\n临时目录将创建在目标文件夹内，确认开始整理？";

            var confirmResult = MessageBox.Show(this, confirmMessage, "确认空间使用和操作", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (confirmResult == DialogResult.No)
            {
                return;
            }

            // 确定最终目标文件夹
            string finalTargetFolder;
            string folderName = Path.GetFileName(sourceFolder.TrimEnd('\\', '/'));
            finalTargetFolder = Path.Combine(targetFolder, $"{folderName}（已整理）");

            if (Directory.Exists(finalTargetFolder))
            {
                var result = MessageBox.Show(this,
                    $"整理文件夹已存在:\n{finalTargetFolder}\n\n是否覆盖？",
                    "确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.No) return;

                // 清空目标文件夹
                try
                {
                    Directory.Delete(finalTargetFolder, true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"无法清空目标文件夹: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // 准备UI
            fileListBox.Items.Clear();
            fileListBox.Items.Add($"开始整理文件到:");
            fileListBox.Items.Add(finalTargetFolder);
            fileListBox.Items.Add($"源文件夹大小: {FormatFileSize(sourceSize)}");
            fileListBox.Items.Add($"可用空间: {FormatFileSize(availableSpace)}");

            if (organizeByYear)
            {
                fileListBox.Items.Add("按年份分类文件");
            }
            else if (organizeByYearMonth)
            {
                fileListBox.Items.Add("按年月分类文件");
            }

            if (flattenSubdirectories)
            {
                fileListBox.Items.Add("注意：将在临时目录中移动所有子文件夹文件到根目录");
            }

            if (createRawFolder)
            {
                fileListBox.Items.Add("已启用RAW照片文件夹");
            }

            //显示总大小
            fileListBox.Items.Add($"总大小: {FormatFileSize(sourceSize)}");
            fileListBox.Items.Add("");

            progressBar.Value = 0;
            progressLabel.Text = "准备开始...";

            // 重置速度显示
            speedLabel.Text = "速度: --";
            progressInfoLabel.Text = "进度: 0% | 已处理: 0/0 文件";
            timeInfoLabel.Text = "已用时: -- | 剩余: --";

            // 启用/禁用按钮
            organizeButton.Enabled = false;
            resetButton.Enabled = false;
            cancelButton.Enabled = true;

            this.operationStartTime = DateTime.Now;  // 记录全局开始时间
            this.totalBytesToCopy = sourceSize; // 记录总字节数
            this.bytesCopiedSoFar = 0; // 重置已拷贝字节数
            this.lastSpeedUpdateTime = DateTime.Now; // 初始化速度更新时间
            this.lastBytesCopied = 0; // 初始化上次字节数

            // 开始后台工作
            OrganizeArguments args = new OrganizeArguments
            {
                SourceFolder = sourceFolder,
                TargetFolder = finalTargetFolder,
                TotalBytesToCopy = sourceSize,
                BytesCopied = 0,
                StartTime = this.operationStartTime
            };

            backgroundWorker.RunWorkerAsync(args);
        }

        private void CancelOrganize()
        {
            if (backgroundWorker.IsBusy)
            {
                backgroundWorker.CancelAsync();
            }
        }

        private string GetRelativePath(string fullPath, string basePath)
        {
            if (!fullPath.StartsWith(basePath))
                return Path.GetFileName(fullPath);

            return fullPath.Substring(basePath.Length).TrimStart('\\', '/');
        }

        private void ResetUI(TextBox sourceFolderPathText, TextBox targetFolderPathText)
        {
            sourceFolderPathText.Text = "";
            targetFolderPathText.Text = "";
            fileListBox.Items.Clear();
            progressBar.Value = 0;
            progressLabel.Text = "等待开始...";

            // 重置速度显示
            speedLabel.Text = "速度: --";
            progressInfoLabel.Text = "进度: 0% | 已处理: 0/0 文件";
            timeInfoLabel.Text = "已用时: -- | 剩余: --";

            selectedFolderPath = "";
            targetFolderPath = "";
            organizeByYear = false;
            organizeByYearMonth = false;
            flattenSubdirectories = false;
            createRawFolder = false;

            // 重置复选框状态
            foreach (Control control in this.Controls)
            {
                if (control is GroupBox groupBox)
                {
                    foreach (Control subControl in groupBox.Controls)
                    {
                        if (subControl is CheckBox checkBox)
                        {
                            checkBox.Checked = false;
                        }
                    }
                }
            }

            // 启用/禁用按钮
            organizeButton.Enabled = true;
            resetButton.Enabled = true;
            cancelButton.Enabled = false;

            statusLabel.Text = "准备就绪";
            statusLabel.ForeColor = Color.DarkBlue;

            // 更新预览
            UpdatePreview();
        }

        // 重写 Dispose 方法以释放 ToolTip 资源
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                toolTip?.Dispose();
            }
            base.Dispose(disposing);
        }

        // 格式化速度显示
        private string FormatSpeed(double bytesPerSecond)
        {
            if (bytesPerSecond <= 0) return "0 B/s";

            string[] units = { "B/s", "KB/s", "MB/s", "GB/s" };
            int unitIndex = 0;
            double speed = bytesPerSecond;

            while (speed >= 1024 && unitIndex < units.Length - 1)
            {
                speed /= 1024;
                unitIndex++;
            }

            return $"{speed:0.##} {units[unitIndex]}";
        }

        // 格式化时间间隔
        private string FormatTimeSpan(TimeSpan timeSpan)
        {
            if (timeSpan.TotalHours >= 1)
                return $"{(int)timeSpan.TotalHours}h {timeSpan.Minutes}m";
            else if (timeSpan.TotalMinutes >= 1)
                return $"{(int)timeSpan.TotalMinutes}m {timeSpan.Seconds}s";
            else
                return $"{timeSpan.Seconds}s";
        }
    }

    // 辅助类
    public class OrganizeArguments
    {
        public string SourceFolder { get; set; }
        public string TargetFolder { get; set; }
        public long TotalBytesToCopy { get; set; }
        public long BytesCopied { get; set; }
        public DateTime StartTime { get; set; }
    }

    public class ProgressInfo
    {
        public string FileName { get; set; }
        public string Stage { get; set; }
        public int ProcessedFiles { get; set; }
        public int TotalFilesInStage { get; set; }
        public int TotalFiles { get; set; }
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }
        public long BytesCopied { get; set; }
        public long TotalBytes { get; set; }
        public double CurrentSpeed { get; set; }
    }

    public class OrganizeResult
    {
        public bool Success { get; set; }
        public int ProcessedFiles { get; set; }
        public int TotalFiles { get; set; }
        public string TargetFolder { get; set; }
        public string ErrorMessage { get; set; }
        public long TotalBytes { get; set; }
        public long BytesCopied { get; set; }
        public DateTime CopyEndTime { get; set; }
    }
}
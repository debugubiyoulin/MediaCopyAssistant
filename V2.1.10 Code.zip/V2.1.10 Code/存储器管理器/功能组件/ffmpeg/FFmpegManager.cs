﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaCopyAssistant
{
    /// <summary>
    /// FFmpeg管理器
    /// </summary>
    public class FFmpegManager
    {
        private string appDataPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Temp",
            "MediaCopyAssistant");

        private string ffmpegPath;
        private readonly string[] requiredFiles = { "ffmpeg.exe", "ffprobe.exe", "ffplay.exe" };

        // FFmpeg下载源
        private readonly Dictionary<string, string> ffmpegSources = new Dictionary<string, string>
        {
            { "官方源", "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-lgpl.zip" },
            { "国内镜像", "https://ghproxy.com/https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-lgpl.zip" }
        };

        public FFmpegManager()
        {
            ffmpegPath = Path.Combine(appDataPath, "ffmpeg");

            // 确保目录存在
            if (!Directory.Exists(ffmpegPath))
                Directory.CreateDirectory(ffmpegPath);
        }

        /// <summary>
        /// 检查FFmpeg完整性
        /// </summary>
        public bool CheckFFmpegIntegrity()
        {
            try
            {
                // 检查所有必需文件是否存在
                foreach (string file in requiredFiles)
                {
                    string filePath = Path.Combine(ffmpegPath, file);
                    if (!File.Exists(filePath))
                        return false;
                }

                // 验证ffmpeg.exe是否能正常运行
                return TestFFmpegExecution();
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 测试FFmpeg执行
        /// </summary>
        private bool TestFFmpegExecution()
        {
            try
            {
                string ffmpegExe = Path.Combine(ffmpegPath, "ffmpeg.exe");

                if (!File.Exists(ffmpegExe))
                    return false;

                using (Process process = new Process())
                {
                    process.StartInfo.FileName = ffmpegExe;
                    process.StartInfo.Arguments = "-version";
                    process.StartInfo.CreateNoWindow = true;
                    process.StartInfo.UseShellExecute = false;
                    process.StartInfo.RedirectStandardOutput = true;
                    process.StartInfo.RedirectStandardError = true;

                    process.Start();

                    // 等待一小段时间获取版本信息
                    if (process.WaitForExit(2000))
                    {
                        string output = process.StandardOutput.ReadToEnd();
                        string error = process.StandardError.ReadToEnd();

                        // 检查输出是否包含FFmpeg版本信息
                        return output.Contains("ffmpeg version") || error.Contains("ffmpeg version");
                    }

                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 获取FFmpeg组件状态
        /// </summary>
        public Dictionary<string, bool> GetComponentStatus()
        {
            var status = new Dictionary<string, bool>();

            foreach (string file in requiredFiles)
            {
                string filePath = Path.Combine(ffmpegPath, file);
                status[file] = File.Exists(filePath);
            }

            return status;
        }

        /// <summary>
        /// 下载并安装FFmpeg
        /// </summary>
        public async Task<bool> DownloadAndInstallFFmpeg(IProgress<int> progress = null,
                                                       IProgress<string> statusProgress = null)
        {
            string tempZipFile = null;
            string extractPath = null;

            try
            {
                statusProgress?.Report("正在选择下载源...");

                // 尝试所有下载源直到成功
                bool downloadSuccess = false;
                string selectedSource = "";

                foreach (var source in ffmpegSources)
                {
                    try
                    {
                        selectedSource = source.Key;
                        statusProgress?.Report($"正在从 {selectedSource} 下载FFmpeg...");

                        tempZipFile = Path.Combine(Path.GetTempPath(), $"ffmpeg_{Guid.NewGuid()}.zip");

                        // 下载文件
                        if (await DownloadFileAsync(source.Value, tempZipFile, progress, statusProgress))
                        {
                            downloadSuccess = true;
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        statusProgress?.Report($"从 {selectedSource} 下载失败: {ex.Message}");

                        // 清理失败的下载
                        if (File.Exists(tempZipFile))
                        {
                            try { File.Delete(tempZipFile); } catch { }
                        }
                    }
                }

                if (!downloadSuccess)
                {
                    statusProgress?.Report("❌ 所有下载源都不可用");
                    return false;
                }

                statusProgress?.Report("正在解压文件...");

                // 解压文件
                extractPath = Path.Combine(Path.GetTempPath(), $"ffmpeg_extract_{Guid.NewGuid()}");

                try
                {
                    ZipFile.ExtractToDirectory(tempZipFile, extractPath);
                }
                catch (Exception ex)
                {
                    statusProgress?.Report($"解压失败: {ex.Message}");
                    return false;
                }

                statusProgress?.Report("正在查找FFmpeg文件...");

                // 获取所有解压出的文件
                List<string> allFiles = GetAllFiles(extractPath);

                // 查找FFmpeg相关文件
                List<string> ffmpegFiles = new List<string>();
                foreach (string file in allFiles)
                {
                    string fileName = Path.GetFileName(file).ToLower();
                    if (requiredFiles.Any(req => req.ToLower() == fileName))
                    {
                        ffmpegFiles.Add(file);
                    }
                }

                if (ffmpegFiles.Count == 0)
                {
                    statusProgress?.Report("❌ 在下载包中找不到FFmpeg可执行文件");
                    return false;
                }

                statusProgress?.Report($"找到 {ffmpegFiles.Count} 个FFmpeg文件，正在安装...");

                // 清理目标文件夹中已有的FFmpeg文件
                foreach (string file in requiredFiles)
                {
                    string filePath = Path.Combine(ffmpegPath, file);
                    if (File.Exists(filePath))
                    {
                        try
                        {
                            File.Delete(filePath);
                        }
                        catch { }
                    }
                }

                // 复制所有找到的FFmpeg文件
                int copiedCount = 0;
                foreach (string sourceFile in ffmpegFiles)
                {
                    string fileName = Path.GetFileName(sourceFile);
                    string destFile = Path.Combine(ffmpegPath, fileName);

                    try
                    {
                        File.Copy(sourceFile, destFile, true);
                        copiedCount++;
                        statusProgress?.Report($"已复制: {fileName}");
                    }
                    catch (Exception ex)
                    {
                        statusProgress?.Report($"复制 {fileName} 失败: {ex.Message}");
                    }
                }

                if (copiedCount > 0)
                {
                    // 验证安装是否成功
                    bool installedSuccess = CheckFFmpegIntegrity();

                    if (installedSuccess)
                    {
                        statusProgress?.Report($"✅ FFmpeg安装完成，安装了 {copiedCount} 个文件");
                        return true;
                    }
                    else
                    {
                        statusProgress?.Report("⚠️ 文件已复制，但完整性检查失败");
                        return false;
                    }
                }
                else
                {
                    statusProgress?.Report("❌ 没有成功安装任何文件");
                    return false;
                }
            }
            catch (Exception ex)
            {
                statusProgress?.Report($"安装失败: {ex.Message}");
                return false;
            }
            finally
            {
                // 清理临时文件
                try
                {
                    if (tempZipFile != null && File.Exists(tempZipFile))
                        File.Delete(tempZipFile);
                }
                catch { }

                try
                {
                    if (extractPath != null && Directory.Exists(extractPath))
                        Directory.Delete(extractPath, true);
                }
                catch { }
            }
        }

        /// <summary>
        /// 获取所有文件（递归）
        /// </summary>
        private List<string> GetAllFiles(string directory)
        {
            var files = new List<string>();

            try
            {
                // 添加当前目录的文件
                files.AddRange(Directory.GetFiles(directory));

                // 递归添加子目录的文件
                foreach (string subDir in Directory.GetDirectories(directory))
                {
                    files.AddRange(GetAllFiles(subDir));
                }
            }
            catch (Exception)
            {
                // 忽略错误
            }

            return files;
        }

        /// <summary>
        /// 异步下载文件
        /// </summary>
        private async Task<bool> DownloadFileAsync(string url, string destination,
                                                 IProgress<int> progress, IProgress<string> status)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.DownloadProgressChanged += (s, e) =>
                    {
                        progress?.Report(e.ProgressPercentage);
                    };

                    await client.DownloadFileTaskAsync(new Uri(url), destination);

                    // 检查文件是否有效
                    if (File.Exists(destination))
                    {
                        FileInfo fileInfo = new FileInfo(destination);
                        if (fileInfo.Length > 1024 * 1024) // 文件大小应大于1MB
                        {
                            return true;
                        }
                        else
                        {
                            status?.Report("下载的文件大小异常，可能不完整");
                            return false;
                        }
                    }
                    else
                    {
                        status?.Report("文件下载后不存在");
                        return false;
                    }
                }
            }
            catch (WebException webEx)
            {
                status?.Report($"网络错误: {webEx.Message}");
                return false;
            }
            catch (Exception ex)
            {
                status?.Report($"下载失败: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// 删除FFmpeg组件
        /// </summary>
        public bool DeleteFFmpegComponents()
        {
            try
            {
                int deletedCount = 0;

                foreach (string file in requiredFiles)
                {
                    string filePath = Path.Combine(ffmpegPath, file);
                    if (File.Exists(filePath))
                    {
                        try
                        {
                            File.Delete(filePath);
                            deletedCount++;
                        }
                        catch { }
                    }
                }

                return deletedCount > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 获取FFmpeg版本信息
        /// </summary>
        public string GetFFmpegVersion()
        {
            try
            {
                string ffmpegExe = Path.Combine(ffmpegPath, "ffmpeg.exe");

                if (!File.Exists(ffmpegExe))
                    return "未安装";

                using (Process process = new Process())
                {
                    process.StartInfo.FileName = ffmpegExe;
                    process.StartInfo.Arguments = "-version";
                    process.StartInfo.CreateNoWindow = true;
                    process.StartInfo.UseShellExecute = false;
                    process.StartInfo.RedirectStandardOutput = true;
                    process.StartInfo.RedirectStandardError = true;

                    process.Start();

                    // 等待进程完成
                    process.WaitForExit(3000);

                    // 先读取标准错误输出（FFmpeg通常将版本信息输出到stderr）
                    string error = process.StandardError.ReadToEnd();

                    // 检查错误输出中是否有版本信息
                    if (!string.IsNullOrEmpty(error))
                    {
                        int startIndex = error.IndexOf("ffmpeg version");
                        if (startIndex >= 0)
                        {
                            int endIndex = error.IndexOf(' ', startIndex + 15);
                            if (endIndex > startIndex)
                            {
                                return error.Substring(startIndex, endIndex - startIndex).Trim();
                            }
                            return error.Substring(startIndex).Split('\n')[0].Trim();
                        }
                    }

                    // 如果错误输出中没有，尝试标准输出
                    string output = process.StandardOutput.ReadToEnd();
                    if (!string.IsNullOrEmpty(output))
                    {
                        int startIndex = output.IndexOf("ffmpeg version");
                        if (startIndex >= 0)
                        {
                            int endIndex = output.IndexOf(' ', startIndex + 15);
                            if (endIndex > startIndex)
                            {
                                return output.Substring(startIndex, endIndex - startIndex).Trim();
                            }
                            return output.Substring(startIndex).Split('\n')[0].Trim();
                        }
                    }

                    return "已安装（版本未知）";
                }
            }
            catch
            {
                return "获取失败";
            }
        }

        /// <summary>
        /// 获取FFmpeg可执行文件路径
        /// </summary>
        public string GetFFmpegExecutablePath()
        {
            string ffmpegExe = Path.Combine(ffmpegPath, "ffmpeg.exe");
            return File.Exists(ffmpegExe) ? ffmpegExe : null;
        }

        /// <summary>
        /// 获取FFprobe可执行文件路径
        /// </summary>
        public string GetFFprobeExecutablePath()
        {
            string ffprobeExe = Path.Combine(ffmpegPath, "ffprobe.exe");
            return File.Exists(ffprobeExe) ? ffprobeExe : null;
        }
    }
}
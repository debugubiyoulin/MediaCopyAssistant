﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace MediaCopyAssistant
{
    public partial class DownloadProgressForm : Form
    {
        private ProgressBar progressBar;
        private Label statusLabel;
        private Label sourceLabel;
        private Label speedLabel;
        private Label timeLabel;
        private System.Windows.Forms.Timer updateTimer;
        private DateTime startTime;
        private long totalBytes;
        private long downloadedBytes;
        private long lastBytes;
        private DateTime lastUpdateTime;

        public DownloadProgressForm(string source, string version)
        {
            InitializeComponent(source, version);
            InitializeTimer();
        }

        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 1, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        private void InitializeComponent(string source, string version)
        {
            this.Text = "下载更新 - 媒体拷贝助手";
            this.Size = new Size(600, 300);  // 增大窗体尺寸
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            // 标题
            Label titleLabel = new Label
            {
                Text = "📥 下载更新",
                Location = new Point(20, 20),
                Size = new Size(560, 40),
                Font = GetDefaultFont(18, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.DarkBlue
            };

            // 来源标签
            sourceLabel = new Label
            {
                Text = $"更新源: {source} | 版本: v{version}",
                Location = new Point(20, 70),
                Size = new Size(560, 25),
                Font = GetDefaultFont(10),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.DarkSlateGray
            };

            // 进度条
            progressBar = new ProgressBar
            {
                Location = new Point(20, 110),
                Size = new Size(560, 30),
                Style = ProgressBarStyle.Continuous,
                Minimum = 0,
                Maximum = 100,
                Value = 0
            };

            // 进度百分比标签
            Label percentageLabel = new Label
            {
                Name = "percentageLabel",
                Text = "0%",
                Location = new Point(20, 145),
                Size = new Size(560, 25),
                Font = GetDefaultFont(12, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.DarkBlue
            };

            // 状态标签
            statusLabel = new Label
            {
                Name = "statusLabel",
                Text = "准备下载...",
                Location = new Point(20, 175),
                Size = new Size(560, 25),
                Font = GetDefaultFont(10),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.DarkGreen
            };

            // 速度标签
            speedLabel = new Label
            {
                Name = "speedLabel",
                Text = "速度: --",
                Location = new Point(20, 200),
                Size = new Size(280, 25),
                Font = GetDefaultFont(9),
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Color.DarkRed
            };

            // 时间标签
            timeLabel = new Label
            {
                Name = "timeLabel",
                Text = "用时: --",
                Location = new Point(300, 200),
                Size = new Size(280, 25),
                Font = GetDefaultFont(9),
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Color.DarkOrange
            };

            // 提示信息
            Label infoLabel = new Label
            {
                Text = "📢 下载完成后，程序将自动重启完成更新",
                Location = new Point(20, 230),
                Size = new Size(560, 25),
                Font = GetDefaultFont(9, FontStyle.Bold),
                ForeColor = Color.DarkSlateGray,
                TextAlign = ContentAlignment.MiddleCenter
            };

            // 添加控件到窗体
            this.Controls.Add(titleLabel);
            this.Controls.Add(sourceLabel);
            this.Controls.Add(progressBar);
            this.Controls.Add(percentageLabel);
            this.Controls.Add(statusLabel);
            this.Controls.Add(speedLabel);
            this.Controls.Add(timeLabel);
            this.Controls.Add(infoLabel);
        }

        private void InitializeTimer()
        {
            updateTimer = new System.Windows.Forms.Timer
            {
                Interval = 500 // 每500毫秒更新一次
            };
            updateTimer.Tick += UpdateTimer_Tick;
        }

        /// <summary>
        /// 开始下载
        /// </summary>
        public void StartDownload()
        {
            startTime = DateTime.Now;
            lastUpdateTime = startTime;
            lastBytes = 0;
            downloadedBytes = 0;
            updateTimer.Start();

            // 确保窗体可见
            this.Show();
            this.BringToFront();
            this.Activate();
        }

        /// <summary>
        /// 更新进度（使用字节数）
        /// </summary>
        public void UpdateProgress(long bytesReceived, long totalBytesToReceive)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action(() => UpdateProgress(bytesReceived, totalBytesToReceive)));
                return;
            }

            downloadedBytes = bytesReceived;
            totalBytes = totalBytesToReceive;

            if (totalBytes > 0)
            {
                int percentage = (int)((bytesReceived * 100) / totalBytes);
                UpdateProgress(percentage);
            }
        }

        /// <summary>
        /// 更新进度（使用百分比）
        /// </summary>
        public void UpdateProgress(int percentage)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action(() => UpdateProgress(percentage)));
                return;
            }

            try
            {
                percentage = Math.Min(100, Math.Max(0, percentage));

                // 更新进度条
                progressBar.Value = percentage;

                // 更新百分比标签
                Label percentageLabel = this.Controls.Find("percentageLabel", false)[0] as Label;
                if (percentageLabel != null)
                {
                    percentageLabel.Text = $"{percentage}%";

                    // 根据进度改变颜色
                    if (percentage < 30)
                        percentageLabel.ForeColor = Color.Red;
                    else if (percentage < 70)
                        percentageLabel.ForeColor = Color.Orange;
                    else
                        percentageLabel.ForeColor = Color.Green;
                }

                // 更新状态标签
                UpdateStatusText(percentage);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"更新进度时出错: {ex.Message}");
            }
        }

        /// <summary>
        /// 更新状态文本
        /// </summary>
        private void UpdateStatusText(int percentage)
        {
            if (statusLabel != null)
            {
                if (percentage == 0)
                {
                    statusLabel.Text = "正在初始化下载...";
                    statusLabel.ForeColor = Color.DarkBlue;
                }
                else if (percentage < 100)
                {
                    string status = $"正在下载更新... ({percentage}%)";
                    statusLabel.Text = status;
                    statusLabel.ForeColor = Color.DarkGreen;
                }
                else
                {
                    statusLabel.Text = "✅ 下载完成，准备安装...";
                    statusLabel.ForeColor = Color.Green;
                }
            }
        }

        /// <summary>
        /// 定时器事件，更新速度和用时
        /// </summary>
        private void UpdateTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime now = DateTime.Now;
                TimeSpan elapsed = now - startTime;

                // 计算下载速度
                if (lastBytes > 0 && downloadedBytes > lastBytes)
                {
                    double bytesPerSecond = (downloadedBytes - lastBytes) / 0.5; // 0.5秒间隔
                    string speedText = FormatSpeed(bytesPerSecond);
                    speedLabel.Text = $"速度: {speedText}";

                    // 根据速度设置颜色
                    if (bytesPerSecond > 5 * 1024 * 1024) // > 5 MB/s
                        speedLabel.ForeColor = Color.Green;
                    else if (bytesPerSecond > 1 * 1024 * 1024) // > 1 MB/s
                        speedLabel.ForeColor = Color.Orange;
                    else
                        speedLabel.ForeColor = Color.Red;
                }

                // 更新时间显示
                timeLabel.Text = $"用时: {FormatTimeSpan(elapsed)}";

                // 更新上次记录
                lastBytes = downloadedBytes;
                lastUpdateTime = now;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"更新计时器时出错: {ex.Message}");
            }
        }

        /// <summary>
        /// 格式化速度显示
        /// </summary>
        private string FormatSpeed(double bytesPerSecond)
        {
            if (bytesPerSecond < 1024)
                return $"{bytesPerSecond:F0} B/s";
            else if (bytesPerSecond < 1024 * 1024)
                return $"{(bytesPerSecond / 1024):F1} KB/s";
            else
                return $"{(bytesPerSecond / (1024 * 1024)):F1} MB/s";
        }

        /// <summary>
        /// 格式化时间间隔
        /// </summary>
        private string FormatTimeSpan(TimeSpan timeSpan)
        {
            if (timeSpan.TotalHours >= 1)
                return $"{(int)timeSpan.TotalHours}h {timeSpan.Minutes}m {timeSpan.Seconds}s";
            else if (timeSpan.TotalMinutes >= 1)
                return $"{(int)timeSpan.TotalMinutes}m {timeSpan.Seconds}s";
            else
                return $"{timeSpan.Seconds}s";
        }

        /// <summary>
        /// 下载完成
        /// </summary>
        public void DownloadComplete(bool success)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action(() => DownloadComplete(success)));
                return;
            }

            updateTimer.Stop();

            if (success)
            {
                progressBar.Value = 100;

                Label percentageLabel = this.Controls.Find("percentageLabel", false)[0] as Label;
                if (percentageLabel != null)
                {
                    percentageLabel.Text = "100%";
                    percentageLabel.ForeColor = Color.Green;
                }

                statusLabel.Text = "✅ 下载完成！正在安装更新...";
                statusLabel.ForeColor = Color.Green;

                // 等待2秒后自动关闭
                Timer closeTimer = new Timer { Interval = 2000 };
                closeTimer.Tick += (s, e) =>
                {
                    closeTimer.Stop();
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                };
                closeTimer.Start();
            }
            else
            {
                statusLabel.Text = "❌ 下载失败，请检查网络连接";
                statusLabel.ForeColor = Color.Red;
            }
        }

        /// <summary>
        /// 窗体关闭事件
        /// </summary>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            updateTimer?.Stop();
            updateTimer?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
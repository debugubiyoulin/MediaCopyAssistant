﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;

namespace MediaCopyAssistant
{
    public class CarGameForm : Form
    {
        // 游戏常量
        private const int ROAD_WIDTH = 400;
        private const int GAME_HEIGHT = 600;
        private const int CAR_WIDTH = 40;
        private const int CAR_HEIGHT = 70;
        private const int OBSTACLE_WIDTH = 50;
        private const int OBSTACLE_HEIGHT = 50;

        // 游戏变量
        private float playerX; // 使用浮点数实现平滑移动
        private int playerY;
        private int score = 0;
        private int gameSpeed = 5; // 实际游戏速度
        private int displayedSpeedLevel = 1; // 显示的速度等级
        private bool isGameOver = false;
        private bool isPaused = false;
        private Random random = new Random();

        // 障碍物列表
        private List<Obstacle> obstacles = new List<Obstacle>();

        // 道路标记
        private int roadMarkOffset = 0;

        // 游戏计时器
        private Timer gameTimer;

        // 方向键状态
        private bool leftPressed = false;
        private bool rightPressed = false;

        // 移动速度 - 固定值
        private const float MOVE_SPEED = 5.0f;

        // 颜色定义
        private Color roadColor = Color.FromArgb(80, 80, 80);
        private Color laneMarkColor = Color.White;
        private Color playerCarColor = Color.Red;

        // 障碍物类
        private class Obstacle
        {
            public float X { get; set; } // 使用浮点数实现连续位置
            public int Y { get; set; }
            public int Type { get; set; }
        }

        // 组件
        private System.ComponentModel.IContainer components = null;

        public CarGameForm()
        {
            InitializeComponent();
            InitializeGame();
        }

        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 1, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(ROAD_WIDTH + 200, GAME_HEIGHT);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "小（叉）车快跑";
            this.BackColor = Color.DarkGreen;
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Icon = MediaCopyAssistant.Properties.Resources.小叉车快跑;
        }

        private void InitializeGame()
        {
            // 初始化玩家位置在道路中央
            playerX = (ROAD_WIDTH - CAR_WIDTH) / 2.0f;
            playerY = GAME_HEIGHT - CAR_HEIGHT - 20;

            // 重置所有游戏变量
            score = 0;
            gameSpeed = 5; // 实际游戏速度保持不变
            displayedSpeedLevel = 1; // 显示的速度等级初始为1
            isGameOver = false;
            isPaused = false;
            obstacles.Clear();
            roadMarkOffset = 0;

            // 重置按键状态
            leftPressed = false;
            rightPressed = false;

            // 如果计时器存在，先停止
            if (gameTimer != null)
            {
                gameTimer.Stop();
                gameTimer.Dispose();
            }

            // 创建新的计时器
            gameTimer = new Timer(this.components);
            gameTimer.Interval = 16;
            gameTimer.Tick += new EventHandler(GameTimer_Tick);
            gameTimer.Start();

            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CarGameForm_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CarGameForm_KeyUp);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.CarGameForm_Paint);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (!isPaused && !isGameOver)
            {
                UpdateGame();
            }
            this.Invalidate();
        }

        private void UpdateGame()
        {
            // 更新道路标记
            roadMarkOffset = (roadMarkOffset + gameSpeed) % 40;

            // 处理持续移动
            HandleContinuousMovement();

            // 生成障碍物
            GenerateObstacles();

            MoveObstacles();
            CheckCollisions();
            score++;

            // 每200分增加速度
            UpdateGameSpeed();
        }

        private void UpdateGameSpeed()
        {
            // 每200分增加1级速度
            if (score > 0 && score % 200 == 0)
            {
                // 实际游戏速度增加
                gameSpeed++;

                // 显示的速度等级也增加
                displayedSpeedLevel++;
            }

            // 限制最大速度
            if (gameSpeed > 20)
            {
                gameSpeed = 20;
            }

            // 限制最大显示速度等级
            if (displayedSpeedLevel > 16) // 5+15=20，所以显示16级对应实际速度20
            {
                displayedSpeedLevel = 16;
            }
        }

        private void HandleContinuousMovement()
        {
            // 线性左右移动 - 固定速度
            if (leftPressed)
            {
                playerX -= MOVE_SPEED;
                // 限制在道路范围内
                if (playerX < 0) playerX = 0;
            }
            else if (rightPressed)
            {
                playerX += MOVE_SPEED;
                // 限制在道路范围内
                if (playerX > ROAD_WIDTH - CAR_WIDTH) playerX = ROAD_WIDTH - CAR_WIDTH;
            }
        }

        private void GenerateObstacles()
        {
            // 大幅减少障碍物生成概率
            // 基础生成概率从3%降到1%，随速度增加的幅度也减小
            int spawnChance = 1 + (gameSpeed / 4); // 基础1%，随速度增加幅度减半

            // 确保不会生成过多障碍物 - 最大数量从8个减少到5个
            if (obstacles.Count < 5 && random.Next(100) < spawnChance)
            {
                // 在道路范围内随机生成锥桶位置
                float obstacleX = random.Next(ROAD_WIDTH - OBSTACLE_WIDTH);
                int type = random.Next(10) < 2 ? 1 : 0; // 20%几率生成特殊锥桶

                obstacles.Add(new Obstacle
                {
                    X = obstacleX,
                    Y = -OBSTACLE_HEIGHT,
                    Type = type
                });
            }
        }

        private void MoveObstacles()
        {
            for (int i = obstacles.Count - 1; i >= 0; i--)
            {
                obstacles[i].Y += gameSpeed;

                if (obstacles[i].Y > GAME_HEIGHT)
                {
                    obstacles.RemoveAt(i);
                }
            }
        }

        private void CheckCollisions()
        {
            // 创建更精确的玩家碰撞区域
            // 使用比视觉更小的碰撞框，提高游戏体验
            int collisionPadding = 5;
            Rectangle playerRect = new Rectangle(
                (int)playerX + collisionPadding,
                playerY + collisionPadding,
                CAR_WIDTH - collisionPadding * 2,
                CAR_HEIGHT - collisionPadding * 2);

            foreach (var obstacle in obstacles)
            {
                // 创建更精确的障碍物碰撞区域
                // 障碍物的碰撞区域比视觉更小，特别是顶部
                Rectangle obstacleRect = new Rectangle(
                    (int)obstacle.X + 10,
                    obstacle.Y + 15,
                    OBSTACLE_WIDTH - 20,
                    OBSTACLE_HEIGHT - 20);

                if (playerRect.IntersectsWith(obstacleRect))
                {
                    GameOver();
                    return;
                }
            }
        }

        private void GameOver()
        {
            isGameOver = true;
            if (gameTimer != null)
            {
                gameTimer.Stop();
            }
        }

        private void CarGameForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            DrawRoad(g);
            DrawObstacles(g);
            DrawPlayerCar(g);
            DrawSidebar(g);
            DrawGameStatus(g);
        }

        private void DrawRoad(Graphics g)
        {
            g.FillRectangle(new SolidBrush(roadColor), 0, 0, ROAD_WIDTH, GAME_HEIGHT);

            // 绘制道路标记线（仅作视觉参考）
            for (int i = 1; i <= 3; i++)
            {
                int x = i * (ROAD_WIDTH / 4);
                for (int y = roadMarkOffset; y < GAME_HEIGHT; y += 40)
                {
                    g.FillRectangle(new SolidBrush(laneMarkColor), x - 2, y, 4, 20);
                }
            }

            g.DrawLine(new Pen(Color.White, 3), 0, 0, 0, GAME_HEIGHT);
            g.DrawLine(new Pen(Color.White, 3), ROAD_WIDTH, 0, ROAD_WIDTH, GAME_HEIGHT);
        }

        private void DrawPlayerCar(Graphics g)
        {
            Rectangle carRect = new Rectangle((int)playerX, playerY, CAR_WIDTH, CAR_HEIGHT);
            g.FillRectangle(new SolidBrush(playerCarColor), carRect);

            g.FillRectangle(Brushes.LightBlue, (int)playerX + 5, playerY + 5, CAR_WIDTH - 10, 15);
            g.FillRectangle(Brushes.LightBlue, (int)playerX + 5, playerY + 30, CAR_WIDTH - 10, 15);

            g.FillEllipse(Brushes.Black, (int)playerX + 5, playerY + 5, 8, 8);
            g.FillEllipse(Brushes.Black, (int)playerX + CAR_WIDTH - 13, playerY + 5, 8, 8);
            g.FillEllipse(Brushes.Black, (int)playerX + 5, playerY + CAR_HEIGHT - 13, 8, 8);
            g.FillEllipse(Brushes.Black, (int)playerX + CAR_WIDTH - 13, playerY + CAR_HEIGHT - 13, 8, 8);

            g.FillEllipse(Brushes.Yellow, (int)playerX + 3, playerY + 20, 6, 4);
            g.FillEllipse(Brushes.Yellow, (int)playerX + CAR_WIDTH - 9, playerY + 20, 6, 4);
        }

        private void DrawObstacles(Graphics g)
        {
            foreach (var obstacle in obstacles)
            {
                int x = (int)obstacle.X;
                Rectangle obstacleRect = new Rectangle(x, obstacle.Y, OBSTACLE_WIDTH, OBSTACLE_HEIGHT);

                if (obstacle.Type == 0)
                {
                    // 普通锥桶 - 橙色
                    g.FillRectangle(new SolidBrush(Color.Orange),
                        x + OBSTACLE_WIDTH / 2 - 5, obstacle.Y, 10, OBSTACLE_HEIGHT);

                    g.FillEllipse(Brushes.Orange, x, obstacle.Y - 5, OBSTACLE_WIDTH, 10);

                    g.FillRectangle(Brushes.White, x + OBSTACLE_WIDTH / 2 - 2, obstacle.Y + 10, 4, OBSTACLE_HEIGHT - 20);

                    // 反光条
                    g.FillRectangle(Brushes.Yellow, x + OBSTACLE_WIDTH / 2 - 1, obstacle.Y + 20, 2, 10);
                }
                else
                {
                    // 特殊锥桶 - 红色，更醒目
                    g.FillRectangle(new SolidBrush(Color.Red),
                        x + OBSTACLE_WIDTH / 2 - 5, obstacle.Y, 10, OBSTACLE_HEIGHT);

                    g.FillEllipse(Brushes.Red, x, obstacle.Y - 5, OBSTACLE_WIDTH, 10);

                    g.FillRectangle(Brushes.White, x + OBSTACLE_WIDTH / 2 - 2, obstacle.Y + 10, 4, OBSTACLE_HEIGHT - 20);

                    // 特殊标记
                    g.FillEllipse(Brushes.Yellow, x + OBSTACLE_WIDTH / 2 - 3, obstacle.Y + 25, 6, 6);
                }
            }
        }

        private void DrawSidebar(Graphics g)
        {
            int sidebarX = ROAD_WIDTH;

            g.FillRectangle(new SolidBrush(Color.FromArgb(40, 40, 40)),
                sidebarX, 0, 200, GAME_HEIGHT);

            g.DrawLine(Pens.White, sidebarX, 0, sidebarX, GAME_HEIGHT);
        }

        private void DrawGameStatus(Graphics g)
        {
            int startX = ROAD_WIDTH + 10;
            int startY = 20;

            string statusText = isGameOver ? "游戏结束!" : (isPaused ? "游戏暂停" : "无限狂飙中");
            Color statusColor = isGameOver ? Color.Red : (isPaused ? Color.Yellow : Color.LightGreen);

            // 使用统一的字体方法
            g.DrawString($"状态: {statusText}",
                GetDefaultFont(12f, FontStyle.Bold),
                new SolidBrush(statusColor), startX, startY);

            g.DrawString($"得分: {score}",
                GetDefaultFont(12f, FontStyle.Bold), Brushes.White, startX, startY + 40);

            g.DrawString($"速度等级: {displayedSpeedLevel}级",
                GetDefaultFont(12f, FontStyle.Bold), Brushes.White, startX, startY + 80);

            g.DrawString($"距离: {score / 10}m",
                GetDefaultFont(12f, FontStyle.Bold), Brushes.White, startX, startY + 120);

            g.DrawString("控制说明:",
                GetDefaultFont(10f, FontStyle.Bold), Brushes.Yellow, startX, startY + 200);

            string[] controls = {
                "← → : 左右移动",
                "R : 重新开始",
                "ESC : 退出游戏"
            };

            for (int i = 0; i < controls.Length; i++)
            {
                g.DrawString(controls[i],
                    GetDefaultFont(9f, FontStyle.Regular),
                    Brushes.LightGray, startX, startY + 230 + i * 20);
            }

            if (isGameOver)
            {
                g.DrawString($"最终得分: {score}",
                    GetDefaultFont(16f, FontStyle.Bold),
                    Brushes.Orange, startX, startY + 320);

                g.DrawString($"最终速度等级: {displayedSpeedLevel}级",
                    GetDefaultFont(12f, FontStyle.Bold),
                    Brushes.Yellow, startX, startY + 360);

                g.DrawString("按 R 键重新开始",
                    GetDefaultFont(14f, FontStyle.Bold),
                    Brushes.Yellow, startX, startY + 400);
            }
        }

        private void CarGameForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (isGameOver)
            {
                if (e.KeyCode == Keys.R)
                {
                    RestartGame();
                }
                else if (e.KeyCode == Keys.Escape)
                {
                    this.Close();
                }
                return;
            }

            switch (e.KeyCode)
            {
                case Keys.Left:
                    leftPressed = true;
                    break;

                case Keys.Right:
                    rightPressed = true;
                    break;

                case Keys.R:
                    RestartGame();
                    break;

                case Keys.Escape:
                    this.Close();
                    break;
            }
        }

        private void CarGameForm_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    leftPressed = false;
                    break;

                case Keys.Right:
                    rightPressed = false;
                    break;
            }
        }

        private void RestartGame()
        {
            // 重新初始化游戏，确保所有变量都重置
            InitializeGame();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
                if (gameTimer != null)
                {
                    gameTimer.Stop();
                    gameTimer.Dispose();
                }
            }
            base.Dispose(disposing);
        }
    }
}